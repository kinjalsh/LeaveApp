myApp.controller('NewLeaveCtrl', ['$scope', function($scope) {
// $scope.user.floating = "";
 $scope.checkDateErr = function(startDate,endDate) {
  /* console.log("calling function");
  console.log($scope.user.StartDate);
  console.log($scope.user.EndDate); */
  if(new Date($scope.user.StartDate) > new Date($scope.user.EndDate)){
   $scope.errMessage = '*End Date should be greater than start date';
   /* console.log($scope.StartDate);
   console.log($scope.EndDate);
   console.log($scope.errMessage); */
   return false;
  }
 };
 $scope.checkhalf_day1 = function(half_day1) {
  /* console.log("calling function checkhalf_day1");
  console.log($scope.user.half_day1); */
  if(!$scope.user.half_day1){
   $scope.user.half_day1_value="";
  }
 };
 $scope.checkhalf_day2 = function(half_day2) {
  /* console.log("calling function checkhalf_day2");
  console.log($scope.user.half_day2); */
  if(!$scope.user.half_day2){
   $scope.user.half_day2_value="";
  }
 };
 $scope.floating = function() {
  /* console.log("calling function floating");
  console.log($scope.user.leave); */
  if($scope.user.leave == "FH1" || $scope.user.leave == "FH2"){
   /* console.log("inside if");
   console.log($scope.user.floating_value); */
   $scope.user.floating_value = true;
  }
  else{
   / console.log("inside else"); /
   $scope.user.floating_value = false;
   $scope.user.floating = "";
  }
  / console.log("$scope.floating_value : " +$scope.user.floating_value); /
 };
 
 $scope.master = {};
 $scope.update = function(user) {
  $scope.master = angular.copy(user);
  console.log(user);
 };

 $scope.reset = function() {
  $scope.user = angular.copy($scope.master);
 };

 / $scope.user.half_day1_value = $scope.user.half_day1 ? 0 : $scope.user.half_day1_value; /
 
$scope.reset();
}]);