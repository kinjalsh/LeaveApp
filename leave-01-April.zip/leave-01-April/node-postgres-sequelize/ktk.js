'use strict';
angular.module('postgreDbApp.services', [])

.factory('getEmployeeService', function($http, $q) {
    return {
        getEmployee: function() {
         
         var deferred = $q.defer();

            $http.get('/leave/api/employee/')
            .success(function(data) {
                deferred.resolve(data);
            })
            .error(function(reason) {
                deferred.reject(data);
            });
            return deferred.promise
        }
    };
})

.factory('addNewLeaveService', function ($http, $q) {
    return {
        addLeave: function (user) {

            var deferred = $q.defer();

            user.EmployeeId = 15007;

            $http.post('/leave/api/leave', user)
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (reason) {
                deferred.reject(reason);
            });
            return deferred.promise
        }
    }
})