angular.module('myApp.controllers', ['myApp.services'])
.controller('LoginCtrl', function($http,$scope, EmployeeService){
        $scope.login = function() {
					console.log($scope.emp.empCode);
					EmployeeService.setEmployee($scope.emp.empCode);

				}


})
.controller('EmpCtrl', function($http,$scope, EmployeeService){
$scope.empcode = EmployeeService.getEmployee();
 $scope.employee=[];

 $http.get("/leave/api/employee/").success(function(data,status,headers,config){
  $scope.employee = data;
 $scope.employee.empCode = $scope.empcode;
 }).error(function(data,status,headers,config){
  console.log("Data Not Loaded");
 });

 $scope.floating = function() {
  if($scope.emp.leave == "FH1" || $scope.emp.leave == "FH2"){
   $scope.emp.floating_value = true;
  }
  else{
   / console.log("inside else"); /
   $scope.emp.floating_value = false;
   $scope.emp.floating = "";
  }
  / console.log("$scope.floating_value : " +$scope.user.floating_value); /
 };

 $scope.checkhalf_day1 = function(half_day1) {
  if(!$scope.emp.half_day1){
   $scope.emp.half_day1_value="";
 }
 };

 $scope.checkhalf_day2 = function(half_day2) {
  if(!$scope.emp.half_day2){
   $scope.emp.half_day2_value="";
  }
 };

 $scope.checkDateErr = function(startDate,endDate) {
   if(new Date($scope.emp.StartDate) > new Date($scope.emp.EndDate)){
    $scope.errMessage = '*End Date should be greater than start date';
    return false;
   }
  };

$scope.master = {};
 $scope.update = function(emp) {
  $scope.master = angular.copy(emp);
  console.log("emp :" + emp);
 };

});
