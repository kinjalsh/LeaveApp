This Leave application has 2 static employee codes to be filled in: 15006 and 15007

There is records.json file from where the details based on the employee code filled are being fetched.

Check approved leaves: On clicking this, it shows the list of applied leaves with all the details.

After clicking 'Check approved leaves' button, click 'Add new leave button',

Add New Leave: There are all kinds of validations like min and max date settings based on the 'type of leave' selection, enabling/disabling the floating list, etc

ft.json is the file containing static floating leaves which is being fetched when the leave type is "FH1" or "FH2". Based on the floating leave selection, dates are being set.

On submitting the form, the entire object will be pushed to leaves array, which is reflected in the leaves list..
