'use strict';

angular.module('postgreDbApp.controllers', [])
.controller('MainCtrl', function ($scope, $filter, $q, getEmployeeService, addNewLeaveService, getAppliedLeavesService, getFloatingListService) {

    $scope.employee = {};
    $scope.user = {};
	$scope.floatingList = {};
	$scope.leaveList = {};
	
	
	/*
	 * Get Employee
	 */
    getEmployeeService.getEmployee()
		.then(function(answer) {
		    $scope.employee = answer;
		    $scope.employee.EmployeeId = $scope.employee[0].EmployeeId;
		    $scope.user.EmployeeId = $scope.employee[0].EmployeeId;
			/*
			 * Get AppliedLeaves
			 */
			getAppliedLeavesService.getAppliedLeaves($scope.user.EmployeeId)
				.then(function(answer) {
					$scope.leaveList = answer;
					
				},
				function(error) {
					console.log("OOPS!!!! " + JSON.stringify(error));
				}
			);
			
		},
		function(error) {
			console.log("OOPS!!!! " + JSON.stringify(error));
		}
  	);
	
	
	
	 /*
	 * Get FloatingList
	 */
    /* getFloatingListService.getFloatingList()
		.then(function(answer) {
		    $scope.floatingList = answer;
		},
		function(error) {
			console.log("OOPS!!!! " + JSON.stringify(error));
		}
  	); */
	 
    /*
	 * Add New Leave
	 */

    $scope.addLeave = function () {
        addNewLeaveService.addLeave($scope.user)
            .then(function (answer) {
                $scope.employee = answer;
                $scope.user = {};
            },
            function (error) {
                console.log("OOPS Error Adding Leave!!!! " + JSON.stringify(error));
            }
        );
    };
	
	/*
	 * Get Employee
	 */
	/* getAppliedLeavesService.getAppliedLeaves($scope.user.EmployeeId)
		.then(function(answer) {
			$scope.leaveList = answer;
			
		},
		function(error) {
			console.log("OOPS!!!! " + JSON.stringify(error));
		}
	); */
	
	

    $scope.checkDateErr = function (startDate, endDate) {
        console.log("calling function");
        console.log($scope.user.startDate);
        console.log($scope.user.endDate);
        if (new Date($scope.user.startDate) > new Date($scope.user.endDate)) {
            $scope.errMessage = '*End Date should be greater than start date';
            console.log($scope.user.startDate);
            console.log($scope.user.endDate);
            console.log($scope.errMessage);
            return false;
        }
        else {
            $scope.errMessage = '';
        }
    };
	
	$scope.floating = function() {
		//console.log("calling function floating");
		//console.log($scope.user.leaveType);
		$scope.user.startDate = "";
		$scope.user.endDate = "";
		var today = new Date();
		var tomorrow = new Date(+new Date() + 86400000);
		var yesterday = new Date(+new Date() - 86400000);
		today = $filter('date')(today, "yyyy-MM-dd");
		tomorrow = $filter('date')(tomorrow, "yyyy-MM-dd");
		yesterday = $filter('date')(yesterday, "yyyy-MM-dd");
		if($scope.user.leaveType == "FH1" || $scope.user.leaveType == "FH2"){
			/* console.log("inside if");
			console.log($scope.user.floating_value); */
			$scope.user.floating_value = true;
			$scope.user.isStartHalf = false;
			$scope.user.isEndHalf = false;
			//$scope.user.floating = 
		}
		else if($scope.user.leaveType == "PL"){
			$scope.user.floating_value = false;
			var myEl = angular.element( document.querySelector( '#startDate' ) );
			myEl.attr('min',tomorrow);
			myEl = angular.element( document.querySelector( '#startDate' ) );
			myEl.attr('max',"");
			myEl = angular.element( document.querySelector( '#endDate' ) );
			myEl.attr('min',tomorrow);
			myEl = angular.element( document.querySelector( '#endDate' ) );
			myEl.attr('max',"");
			$scope.floating_day = "";
		}
		else if($scope.user.leaveType == "UL"){
			$scope.user.floating_value = false;
			var myEl = angular.element( document.querySelector( '#endDate' ) );
			myEl.attr('max',yesterday);
			myEl = angular.element( document.querySelector( '#endDate' ) );
			myEl.attr('min',"");
			myEl = angular.element( document.querySelector( '#startDate' ) );
			myEl.attr('max',yesterday);
			myEl = angular.element( document.querySelector( '#startDate' ) );
			myEl.attr('min',"");
			
		}

	};
	
	$scope.changefloating = function(date){
		//console.log("date = "+date);
		if(date === null){
			$scope.user.startDate = new Date("");
			$scope.user.endDate = new Date("");
		}
		else{	
			$scope.user.startDate = new Date(date);
			$scope.user.endDate = new Date(date);
		}
	};

    $scope.checkhalf_day1 = function (isStartHalf) {
        if (!$scope.user.isStartHalf) {
            $scope.user.startHalf = "";
        }
    };
    $scope.checkhalf_day2 = function (half_day2) {
        if (!$scope.user.half_day2) {
            $scope.user.half_day2_value = "";
        }
    };
    /* $scope.floating = function () {
        if ($scope.user.leaveType == "FH1" || $scope.user.leaveType == "FH2") {
            $scope.user.floating_value = true;
        }
        else {
            $scope.user.floating_value = false;
            $scope.user.floating = "";
        }
    }; */

    $scope.getStoreData = function (emp_id) {
        $scope.user.EmployeeId = emp_id;
        //console.log("$scope.user.EmployeeId :" + $scope.user.EmployeeId);
		//console.log($scope.user.EmployeeId);
		getAppliedLeavesService.getAppliedLeaves($scope.user.EmployeeId)
				.then(function(answer) {
					$scope.leaveList = answer;
					
				},
				function(error) {
					console.log("OOPS!!!! " + JSON.stringify(error));
				}
			);	

		
    };
	
	
	$scope.setDateRange = function(startDate) {
	
		//console.log("startDate : " + $scope.user.startDate);
		var minDate = $filter('date')($scope.user.startDate, "yyyy-MM-dd");
		var myEl = angular.element( document.querySelector( '#endDate' ) );
		
		//console.log("minDate : " +minDate);
		//console.log("myEl : " +myEl);
		
		myEl.attr('min',minDate);
		$scope.user.endDate = "";
	};
	
    

});

    
