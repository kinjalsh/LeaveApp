
var myApp = angular.module('myApp',['ngAnimate','ui.bootstrap']);

		myApp.controller('EmpCtrl', function($scope, $http){
				$scope.emp = {};
				/*Getting the json data for employees list*/
				$http.get('data/employees.json').success(function(data){
					$scope.employees = data;
				}).error(function(){
					console.log("error");
				});
		});
			/*Initializing the modal through open method*/
		myApp.controller('ModalDemoCtrl', ['$scope', '$uibModal', '$log', function($scope,$uibModal, $log){
				$scope.open = function(emp) {
					console.log(emp);
					var modalInstance = $uibModal.open({
						templateUrl: 'modal.html',
						controller: 'ModalInstanceCtrl',
						size: 'sm',
						backdrop: 'static',
						scope: $scope,
						resolve: {
							employees: function() {
								return emp;
							}
						}
					});
				}
			}
		]);
 				/*calling the cancel method to close the modal*/
		myApp.controller('ModalInstanceCtrl', ['$scope', '$uibModalInstance', 		'employees',function($scope, $uibModalInstance, employees) {
			$scope.employees = employees;
			$scope.cancel = function() {
				$uibModalInstance.dismiss('cancel');
			};
		}
	]);

			/*Directive for showing list of employees*/
		myApp.directive("employee", function() {
			return {
					scope: '@',
					restrict:'E',
					templateUrl: 'page.html'
				};
		});
