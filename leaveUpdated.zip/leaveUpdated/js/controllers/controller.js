angular.module('myApp.controllers', ['myApp.services'])
.controller('LoginCtrl', function($http,$scope, EmployeeService){

        $scope.login = function() {
					console.log($scope.emp.empCode);
					EmployeeService.setEmployee($scope.emp.empCode);

				}


})
.controller('EmpCtrl', function($http,$scope, EmployeeService){
$scope.empcode = EmployeeService.getEmployee();
		console.log("hergug : "+$scope.empcode);
 $scope.employee=[];
 $http.get("data/records.json").success(function(data,status,headers,config){
  $scope.employee = data;
	//console.log("inside controller code : "+ this.code);
	$scope.employee.empCode = $scope.empcode;
	console.log("$scope.employee.empCode : "+$scope.employee.empCode )
 }).error(function(data,status,headers,config){
  console.log("Data Not Loaded");
 });
 
});
