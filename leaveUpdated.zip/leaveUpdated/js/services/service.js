'use strict';
angular.module('myApp.services', [])
.service('EmployeeService', function () {
  this.empCode;


    this.getEmployee = function() {
      return this.empCode;
    },
    this.setEmployee = function(code) {
      this.empCode = code;
      
      console.log("inside setemployee function");
      console.log("code : "+ code);
      console.log("empCode : "+ this.empCode);
    }
});
