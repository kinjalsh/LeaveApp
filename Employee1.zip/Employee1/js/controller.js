var app = angular.module('MyApp', []);

app.controller('Employee', function($scope){
	$scope.employees = [
	{Name:"John", City:"Phoenix", Designation:"Analyst"},
	{Name:"Smith", City:"Seattle", Designation:"Web Developer"},
	{Name:"Fred", City:"Amsterdam", Designation:"Software Engineer"}
	
	];
	$scope.editing = false;
	
	$scope.addEmp = function(emp) {
			$scope.employees.push(emp);
			$scope.emp = {};
		}
	
	$scope.removeEmp = function(emp){
			$scope.employees.splice(emp,1);
	}
	
	$scope.editEmp = function(emp){
			 $scope.editing = $scope.employees.indexOf(emp);
			   
		}
	$scope.saveField = function(emp) {
        if ($scope.editing !== false) {
			$scope.editing = false;
        } 
		$scope.addEmp = function(emp) {
			$scope.employees.push(emp);
			$scope.emp = {};
		}
	};
});