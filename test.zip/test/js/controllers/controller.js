angular.module('myApp.controllers', [])
.controller('EmpCtrl', function($http,$scope, getDetails){
	$scope.IsVisible = false; //By default Form is hidden
            $scope.ShowHide = function () {
                //If Form is visible, then on click it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
            };
 $scope.employee=[];
 $http.get("data/records.json").success(function(data,status,headers,config){
  console.log(data);
  $scope.employee = data;
 }).error(function(data,status,headers,config){
  console.log("Data Not Loaded");
 });
});