angular.module('myApp.controllers', [])
.controller('EmpCtrl', function($http,$scope, getDetails){
 $scope.employee=[];
 $http.get("data/records.json").success(function(data,status,headers,config){
  console.log(data);
  $scope.employee = data;
 }).error(function(data,status,headers,config){
  console.log("Data Not Loaded");
 });
});